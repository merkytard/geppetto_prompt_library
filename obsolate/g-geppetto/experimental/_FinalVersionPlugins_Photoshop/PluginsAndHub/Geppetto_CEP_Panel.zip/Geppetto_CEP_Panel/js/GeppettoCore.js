// GeppettoCore.jsx
function syncLayers() {
    try {
        // Logika pre synchronizáciu vrstiev
        return "success";
    } catch (e) {
        return "error";
    }
}

function exportProject() {
    try {
        // Logika pre export projektu
        return "success";
    } catch (e) {
        return "error";
    }
}

function exportLayers() {
    try {
        // Logika pre export vrstiev
        return "success";
    } catch (e) {
        return "error";
    }
}