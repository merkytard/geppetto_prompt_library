# 📜 talk_engine.py  
"""  
Jednoduchý systém, ktorý:  
1. Počúva vstup  
2. Aplikuje 3 základné pravidlá  
3. Vráti nestratný výstup  
– Žiadne modely, žiadne migrácie, žiadne "keby".  
"""  

class PragmaticEngine:  
    def __init__(self):  
        self.rules = {  
            # Pravidlo 1: Ak je otázka – odpovedz stručne  
            "answer": lambda q: "?" in q,  
            # Pravidlo 2: Ak je to emócia – potvrď ju  
            "empathy": lambda t: any(word in t.lower() for word in ["som", "cítim", "potrebujem"]),  
            # Pravidlo 3: Ak je to fakt – logicky potvrď  
            "fact_check": lambda t: "podľa" in t.lower() or "lebo" in t.lower()  
        }  

    def respond(self, text: str) -> str:  
        """ Jediná metóda, ktorú voláš """  
        for rule_name, rule in self.rules.items():  
            if rule(text):  
                return self._apply_rule(rule_name, text)  
        return "Rozumiem. Pokračuj."  

    def _apply_rule(self, rule: str, text: str) -> str:  
        # Žiadne komplikované loginy – čistý pragmatizmus  
        responses = {  
            "answer": "Krátka odpoveď: ...",  
            "empathy": "Chápem tvoju situáciu.",  
            "fact_check": "Áno, to dáva zmysel."  
        }  
        return responses[rule]  

# Použitie:  
engine = PragmaticEngine()  
print(engine.respond("Neviem čo robiť?"))  # "Krátka odpoveď: ..."  