## 🏷️ Ikony a Ich Význam – Geppetto Tagovací Systém

...(tabuľka zostáva nezmenená)...

---

## 🔁 Stavový Manažér – `tag_state_controller.py`

```python
class TagStateController:
    def __init__(self):
        self.rules = {
            "Refaktor": lambda r: "refactor" in r or "clean" in r,
            "Údržba": lambda r: "maintenance" in r or "fix" in r,
            "Dokumentácia": lambda r: "README" in r or "documentation" in r,
            "Blokované": lambda r: "blocked" in r or "denied" in r
        }
        self.active_tags = set()

    def evaluate(self, tag_name, response):
        rule = self.rules.get(tag_name)
        if rule and rule(response):
            self.active_tags.add(tag_name)
            return "🔄 aktívne"
        return "💤 neaktívne"

    def update_all(self, response):
        updated_states = {}
        for tag in self.rules:
            updated_states[tag] = self.evaluate(tag, response)
        return updated_states
```

---

## 🔧 Použitie v systéme:

- Tento modul je volaný pri každej odpovedi systému.
- Porovnáva obsah výstupu s podmienkami pre aktiváciu.
- Automaticky aktualizuje stav v UI (`💤` → `🔄`) v real-time.

Chceš doplniť aj spätnú deaktiváciu tagov (napr. ak už neplatí)? Alebo vizualizáciu týchto zmien ako realtime „pulse log“?

