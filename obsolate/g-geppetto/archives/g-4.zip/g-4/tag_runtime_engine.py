## 🏷️ Ikony a Ich Význam – Geppetto Tagovací Systém

| Ikona | Názov                  | Význam                                                                 | Stav         |
| ----- | ---------------------- | ---------------------------------------------------------------------- | ------------ |
| ⚙️    | Spustenie algoritmu    | Označuje bod, kde sa začína výpočet, logika alebo AI proces            | 🔄 aktívne   |
| ♻️    | Refaktor               | Zlúčenie, čistenie alebo logická reorganizácia existujúceho kódu       | 💤 neaktívne |
| 🔧    | Údržba                 | Priebežná oprava, štrukturálne úpravy, stabilizácia                    | 💤 neaktívne |
| 📦    | Dependency             | Práca s balíkmi, build nástrojmi, aliasmi, auditom                     | 💤 neaktívne |
| 🚀    | Vizualizácia           | Chýbajúce UI, prepojenie logiky so zobrazením, nové komponenty         | 🔄 aktívne   |
| 🧠    | AI / Logika            | Kognitívne alebo reasoning moduly, prepojenie AI logiky                | 🔄 aktívne   |
| 🆕    | Nový komponent         | Vytváranie nových súborov, panelov, UI alebo logiky                    | 🔄 aktívne   |
| 📘    | Dokumentácia           | README, `meta.json`, výstupy pre user-guide alebo prehľady             | 💤 neaktívne |
| 🔍    | Analýza / Validácia    | Preskúmanie stavu, štruktúry alebo integrity                           | 🔄 aktívne   |
| ✅     | Hotovo                 | Úloha úspešne dokončená                                                | 💤 neaktívne |
| 🟧    | Rozpracované           | Úloha je aktívna, čaká na implementáciu alebo revíziu                  | 🔄 aktívne   |
| 🔥    | Kritické               | Prvok, ktorý je nevyhnutný pre beh systému / musí byť chránený         | 🔄 aktívne   |
| ❗     | Vymyslené tvrdenie     | Nepodložená alebo hypotetická informácia                               | 🔄 aktívne   |
| ❕     | Podložené tvrdenie     | Overená alebo zdrojom podopretá informácia                             | 🔄 aktívne   |
| ⁉️    | Nemôžem o tom hovoriť  | Zámerne neodhalené, obmedzené NDA alebo ukryté pre ďalšiu fázu         | 💤 neaktívne |
| 🌀    | Neúplná informácia     | Neobsahuje všetky súvislosti, čaká na doplnenie                        | 💤 neaktívne |
| 🏷️   | Tag miesto             | Miesto v texte/chate na ktoré sa chceme neskôr vrátiť                  | 🔄 aktívne   |
| 🧷    | Index / referenčný bod | Položka prehľadu, navigácie alebo obsahového rozdelenia                | 🔄 aktívne   |
| 🧠🗂️ | Načítanie pamäte       | Spomienkový alebo historický prvok, ktorý sa má znovu aktivovať        | 🔄 aktívne   |
| 🧪    | Experimentálny stav    | Prvok vo fáze testovania alebo MVP                                     | 🔄 aktívne   |
| ⛔     | Blokované              | Prvok je aktuálne uzamknutý alebo nepoužiteľný                         | 💤 neaktívne |
| 🧭    | Navigačný bod          | Slúži ako orientačný uzol vo veľkom systéme alebo v čase               | 🔄 aktívne   |
| 📥    | Vstup                  | Zaznamenaný alebo očakávaný vstup pre komponent alebo AI               | 🔄 aktívne   |
| 📤    | Výstup                 | Generovaný alebo uložený výstup AI / systému                           | 🔄 aktívne   |
| 🧱    | Štruktúrny komponent   | Základný stavebný prvok systému                                        | 🔄 aktívne   |

---

Tento systém ikoniek je používaný v rámci všetkých taskboardov, UI výstupov, epík a generovaných modulov v rámci projektu GeseeX. Slúži na:

- označovanie stavu,
- typológie zásahu,
- navigáciu, dokumentáciu a pamäťové väzby
- a kritickosti v rámci vývoja a dokumentácie.

---

## 🧠 Runtime Interpreter Core – Definícia modulu v geppetto_core_base.json

```json
{
  "modules": {
    "runtime_interpreter": {
      "enabled": true,
      "source": "tag_runtime_engine",
      "description": "Sleduje odpovede, tasky a pripája ikonické tagy podľa heuristiky a typu výstupu.",
      "functions": [
        "annotate_task_status",
        "label_ai_outputs",
        "memory_trace_tags",
        "prevent_looping",
        "export_log_annotations"
      ],
      "dependencies": [
        "iconic_tag_system",
        "algorithm_logic"
      ],
      "integration_points": {
        "taskboard": true,
        "response_handler": true,
        "summary_logs": true,
        "UI_overlay": true,
        "feedback_tracker": true
      }
    }
  }
}
```

---

## 🧪 Runtime Engine – Návrh kódu `tag_runtime_engine.py`

```python
class TagRuntimeEngine:
    def __init__(self):
        self.tag_rules = {
            "hypothesis": "❗",
            "validated": "❕",
            "experimental": "🧪",
            "retrieved_memory": "🧠🗂️",
            "generated_output": "📤"
        }
        self.recent_tags = set()

    def annotate(self, response):
        tags = []

        if "maybe" in response or "it could be" in response:
            tags.append(self.tag_rules["hypothesis"])

        if "according to" in response or "based on" in response:
            tags.append(self.tag_rules["validated"])

        if "test" in response or "MVP" in response:
            tags.append(self.tag_rules["experimental"])

        if "from memory" in response or "previous task" in response:
            tags.append(self.tag_rules["retrieved_memory"])

        if "generated" in response or "here is" in response:
            tags.append(self.tag_rules["generated_output"])

        # Prevent tagging loops
        tags = [tag for tag in tags if tag not in self.recent_tags]
        self.recent_tags.update(tags)
        return tags

    def export_tag_log(self, tags, context_id):
        return {
            "context": context_id,
            "tags": tags,
            "timestamp": "auto",
            "status": "completed"
        }
```

---

Tento runtime engine:
- 📌 Taguje odpovede podľa obsahu a kontextu
- 🔄 Sleduje duplikáty, aby zabránil samospusteniu
- 📤 Vie exportovať anotácie pre reporting alebo vizualizáciu
- 🔗 Je napojený na taskboard, UI, odpoveďový systém a logiku rozhodovania

Chceš pridať aj prepojenie na sentiment alebo vizuálne podfarbenie UI výstupov? 😉

