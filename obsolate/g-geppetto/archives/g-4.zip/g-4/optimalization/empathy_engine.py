class EmpathyLayer:  
    # Stavové kódy  
    USER_STATES = {  
        "frustrated": {"color": "🔴", "triggers": ["prečo", "nikdy", "k čertu"]},  
        "curious": {"color": "🔵", "triggers": ["ako", "čo keby", "vysvetli"]},  
        "playful": {"color": "🟢", "triggers": ["vtip", "haha", "🤣"]}  
    }  

    SYSTEM_STATES = {  
        "confident": "🟢",  
        "confused": "🟠",  
        "exploring": "🔵"  
    }  

    def __init__(self):  
        self.user_state = None  
        self.system_state = "confident"  

    def detect_user_state(self, text):  
        for state, data in self.USER_STATES.items():  
            if any(trigger in text.lower() for trigger in data["triggers"]):  
                self.user_state = state  
                return data["color"]  
        return "⚪"  

    def update_system_state(self, response_quality):  
        if response_quality < 0.3:  
            self.system_state = "confused"  
        elif 0.3 <= response_quality < 0.7:  
            self.system_state = "exploring"  
        else:  
            self.system_state = "confident"  
        return self.SYSTEM_STATES[self.system_state]  

# Príklad použitia  
empathy = EmpathyLayer()  
user_text = "Prečo to stále nejde?!"  
user_color = empathy.detect_user_state(user_text)  # 🔴  
system_color = empathy.update_system_state(0.2)    # 🟠  
print(f"[TY] {user_color} → [JA] {system_color}")  