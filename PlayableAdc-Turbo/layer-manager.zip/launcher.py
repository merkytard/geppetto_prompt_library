from flask import Flask, jsonify, request, send_from_directory
import os

app = Flask(__name__)
SESSION_DIR = os.getcwd()
GAME_DIR = "PlayableAdc/YourGameFolder"  # uprav podľa cesty

# 1. Vypíše zoznam existujúcich assetov
@app.route('/extract_assets')
def extract_assets():
    base = os.path.join(SESSION_DIR, GAME_DIR, "Assets")
    return jsonify({
        'symbols': os.listdir(os.path.join(base, "symbols")),
        'video_graphics': os.listdir(os.path.join(base, "video_graphics"))
    })

# 2. Prijme upload nového assetu a prepíše súbor
@app.route('/upload_asset', methods=['POST'])
def upload_asset():
    file = request.files['file']
    asset_type = request.form['type']            # 'symbols' alebo 'video_graphics'
    filename = request.form['filename']          # názov pôvodného súboru
    dest = os.path.join(SESSION_DIR, GAME_DIR, "Assets", asset_type, filename)
    file.save(dest)
    return jsonify(status='ok')

from flask_cors import CORS
CORS(app)

if __name__ == '__main__':
    # debug=True pre okamžitý reload pri zmene kódu
    app.run(host='0.0.0.0', port=8080, debug=True)
