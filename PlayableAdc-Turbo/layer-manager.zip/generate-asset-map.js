const fs = require('fs');
const path = require('path');

function scanAssets(dir) {
  const assets = [];
  fs.readdirSync(dir).forEach(file => {
    if (/\.(png|jpg|json)$/.test(file)) {
      assets.push({
        name: path.parse(file).name,
        path: path.join(dir, file),
        type: file.split('.').pop()
      });
    }
  });
  return { textures: assets };
}
