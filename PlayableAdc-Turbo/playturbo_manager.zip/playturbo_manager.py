import os
import re
import base64
import shutil
from pathlib import Path

class PlayTurboProcessor:
    def __init__(self, session_dir):
        self.session_dir = Path(session_dir)
        self.animation_data = {}
        
    def process_upload(self, zip_file):
        """Spracovanie PlayTurbo ZIP archívu"""
        pt_dir = self.session_dir / "playturbo"
        pt_dir.mkdir(exist_ok=True)
        
        # Uloženie a extrakcia ZIPu
        zip_path = pt_dir / "template.zip"
        zip_file.save(zip_path)
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(pt_dir)
        
        # Analýza štruktúry
        self._analyze_structure(pt_dir)
        return self.animation_data
    
    def _analyze_structure(self, pt_dir):
        """Analýza PlayTurbo štruktúry"""
        self.animation_data = {
            'main_html': None,
            'js_files': [],
            'image_assets': [],
            'base64_assets': []
        }
        
        # Hľadanie hlavného HTML súboru
        for f in pt_dir.glob("*.html"):
            if "playable" in f.name.lower():
                self.animation_data['main_html'] = f
                break
                
        # Zber všetkých relevantných súborov
        for root, _, files in os.walk(pt_dir):
            for file in files:
                file_path = Path(root) / file
                if file.endswith(".js"):
                    self._process_js(file_path)
                elif file.lower().endswith((".png", ".jpg", ".jpeg")):
                    self.animation_data['image_assets'].append(file_path)
    
    def _process_js(self, js_path):
        """Spracovanie JavaScript súborov"""
        with open(js_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Detekcia base64 obrázkov
        base64_images = re.findall(r'data:image/(\w+);base64,([^\'"]+)', content)
        for i, (img_type, data) in enumerate(base64_images):
            output_path = js_path.parent / f"extracted_{i}.{img_type}"
            self._save_base64_image(data, output_path)
            self.animation_data['base64_assets'].append({
                'original_js': js_path,
                'output_path': output_path,
                'position': i
            })
        
        self.animation_data['js_files'].append(js_path)
    
    def _save_base64_image(self, b64_data, output_path):
        """Uloženie base64 obrázku do súboru"""
        img_data = base64.b64decode(b64_data)
        with open(output_path, 'wb') as f:
            f.write(img_data)