class LayerManager {
  constructor(scene) {
    this.layers = {
      background: scene.add.layer(),
      main: scene.add.layer(),
      ui: scene.add.layer()
    };
  }

  addToLayer(sprite, layerName, depth) {
    this.layers[layerName].add(sprite);
    sprite.setDepth(depth);
  }
}
