import React, { useState, useEffect } from "react";
import HueShiftButton from "./HueShiftButton";

const API_ASSETS = "/extract_assets";
const API_UPLOAD = "/upload_asset";

function App() {
  const [symbols, setSymbols] = useState([]);
  const [graphics, setGraphics] = useState([]);
  const [selected, setSelected] = useState({ type: null, filename: null });
  const [refresh, setRefresh] = useState(false);

  useEffect(() => {
    fetch(API_ASSETS)
      .then((res) => res.json())
      .then((data) => {
        setSymbols(data.symbols || []);
        setGraphics(data.video_graphics || []);
      });
  }, [refresh]);

  const onSelect = (type, filename) => {
    setSelected({ type, filename });
  };

  const onReplace = (e) => {
    if (!selected.type || !selected.filename) return;
    const file = e.target.files[0];
    if (!file) return;

    const form = new FormData();
    form.append("file", file);
    form.append("type", selected.type);
    form.append("filename", selected.filename);

    fetch(API_UPLOAD, {
      method: "POST",
      body: form,
    }).then(() => setRefresh((r) => !r));
  };

  return (
    <div style={{ fontFamily: "sans-serif", padding: 24, background: "#eee", minHeight: "100vh" }}>
      <h2>Asset Editor (React + Vite)</h2>
      <div>
        <strong>Symbols</strong>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
          {symbols.map((s) => (
            <div
              key={s}
              style={{
                border: selected.type === "symbols" && selected.filename === s ? "2px solid #ff8800" : "2px solid #ccc",
                borderRadius: 10,
                padding: 4,
                background: "#fff",
                cursor: "pointer",
                boxShadow: "0 2px 8px #0002",
                width: 96,
                textAlign: "center"
              }}
              onClick={() => onSelect("symbols", s)}
            >
              <img
                src={`/session_casino/777_Casino_Slot_Machines_V1_version1/Assets/symbols/${s}`}
                alt={s}
                style={{ width: 64, height: 64, objectFit: "contain" }}
              />
              <div style={{ fontSize: 12, wordBreak: "break-all" }}>{s}</div>
              <HueShiftButton
                src={`/session_casino/777_Casino_Slot_Machines_V1_version1/Assets/symbols/${s}`}
                onHueShifted={(dataUrl) => {
                  // napr. otvor náhľad, nahraď asset, uploadni na server alebo zobraz alert
                  window.open(dataUrl, "_blank");
                }}
              />
            </div>
          ))}
        </div>
        <strong>Video Graphics</strong>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 16 }}>
          {graphics.map((g) => (
            <div
              key={g}
              style={{
                border: selected.type === "video_graphics" && selected.filename === g ? "2px solid #0094ff" : "2px solid #ccc",
                borderRadius: 10,
                padding: 4,
                background: "#fff",
                cursor: "pointer",
                boxShadow: "0 2px 8px #0002",
                width: 96,
                textAlign: "center"
              }}
              onClick={() => onSelect("video_graphics", g)}
            >
              <img
                src={`/session_casino/777_Casino_Slot_Machines_V1_version1/Assets/video_graphics/${g}`}
                alt={g}
                style={{ width: 64, height: 64, objectFit: "contain" }}
              />
              <div style={{ fontSize: 12, wordBreak: "break-all" }}>{g}</div>
              <HueShiftButton
                src={`/session_casino/777_Casino_Slot_Machines_V1_version1/Assets/video_graphics/${g}`}
                onHueShifted={(dataUrl) => {
                  window.open(dataUrl, "_blank");
                }}
              />
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 20 }}>
        <input
          type="file"
          id="replaceFile"
          style={{ display: "none" }}
          accept=".png,.jpg,.jpeg"
          onChange={onReplace}
        />
        <button
          style={{
            background: selected.type ? "#ff8800" : "#aaa",
            color: "#fff",
            padding: "10px 18px",
            fontWeight: 600,
            fontSize: 18,
            border: "none",
            borderRadius: 10,
            boxShadow: "0 2px 8px #0002",
            cursor: selected.type ? "pointer" : "not-allowed"
          }}
          disabled={!selected.type}
          onClick={() => selected.type && document.getElementById("replaceFile").click()}
        >
          Replace selected asset
        </button>
      </div>
    </div>
  );
}

export default App;
