import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/extract_assets": "http://localhost:8080",
      "/upload_asset": "http://localhost:8080"
    }
  },
  build: {
    outDir: "dist"
  }
});
