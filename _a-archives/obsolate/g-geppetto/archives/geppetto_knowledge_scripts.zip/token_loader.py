# 🔐 token_loader.py – bezpečný spôsob, ako uchovávať GitHub token lokálne

# Upozornenie: Token je citlivý údaj. Nezdieľaj verejne!
GITHUB_TOKEN = "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"
