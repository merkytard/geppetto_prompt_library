
import numpy as np
import matplotlib.pyplot as plt

def generate_mirror_echo_grid(matrix_size=6, layers=7):
    fig, axs = plt.subplots(1, layers, figsize=(15, 3))
    for z in range(layers):
        grid = np.zeros((matrix_size, matrix_size))
        for y in range(matrix_size):
            for x in range(matrix_size):
                grid[y, x] = np.sin((x + y + z) * np.pi / 8)
        axs[z].imshow(grid, cmap='coolwarm', interpolation='nearest')
        axs[z].set_title(f"Z={z}")
        axs[z].axis('off')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    generate_mirror_echo_grid()
