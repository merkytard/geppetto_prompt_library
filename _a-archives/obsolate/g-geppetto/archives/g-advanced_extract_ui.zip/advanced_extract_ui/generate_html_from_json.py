#!/usr/bin/env python3
import json

def generate_html(data):
    """Generuje HTML obsah zo štruktúrovaných dát načítaných zo JSON."""
    html = """<!DOCTYPE html>
<html lang="sk">
<head>
  <meta charset="UTF-8">
  <title>UI Generated from JSON</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      padding: 20px;
      background: #f4f4f4;
    }
    h1 {
      text-align: center;
    }
    .global {
      border: 2px solid #444;
      padding: 15px;
      margin: 15px 0;
      border-radius: 5px;
    }
    .global h2 {
      margin-top: 0;
    }
    .module {
      border: 1px solid #ccc;
      padding: 10px;
      margin: 10px;
      border-radius: 3px;
      background: #fff;
    }
    .lock {
      font-size: 0.9rem;
      color: #d0021b;
    }
    .tags {
      font-size: 0.8rem;
      color: #888;
    }
    .action {
      font-size: 0.9rem;
      color: #007acc;
      cursor: pointer;
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <h1>UI Generated from JSON</h1>
"""
    # Prechádzame všetky global modifiers
    for gm in data.get("globalModifiers", []):
        style = gm.get("style", {})
        background = style.get("background", "#ffffff")
        color = style.get("color", "#000000")
        html += f"<div class='global' id='{gm.get('id')}' style='background:{background}; color:{color};'>\n"
        html += f"  <h2>{gm.get('name')}</h2>\n"
        # Pre každý modul v global modifieri
        for mod in gm.get("modules", []):
            html += f"  <div class='module' id='{mod.get('id')}'>\n"
            html += f"    <strong>{mod.get('name')}</strong><br>\n"
            # LOCK informácie, ak existujú
            lock = mod.get("lock")
            if lock:
                html += f"    <div class='lock'>LOCK {lock.get('level')}: {lock.get('reason')} (by {lock.get('by')})</div>\n"
            # Tagy
            tags = mod.get("tags", [])
            if tags:
                html += f"    <div class='tags'>Tags: {' '.join(tags)}</div>\n"
            # Interakcia (naClick) – pre demo účely zobrazíme len text
            interactions = mod.get("interactions", {})
            if interactions.get("onClick"):
                html += f"    <div class='action' onclick=\"alert('Executing: {interactions.get('onClick')}');\">[Action]</div>\n"
            html += "  </div>\n"
        html += "</div>\n"
    html += """
</body>
</html>
"""
    return html

def main():
    input_filename = "U_structure.json"
    output_filename = "generated_ui.html"
    try:
        with open(input_filename, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"Chyba pri načítaní súboru {input_filename}: {e}")
        return

    html_content = generate_html(data)
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"HTML súbor bol úspešne vygenerovaný: {output_filename}")
    except Exception as e:
        print(f"Chyba pri zápise do súboru {output_filename}: {e}")

if __name__ == '__main__':
    main()
