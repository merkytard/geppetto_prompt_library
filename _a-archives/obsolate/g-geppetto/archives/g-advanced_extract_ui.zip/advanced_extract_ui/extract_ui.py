#!/usr/bin/env python3
import cv2
import pytesseract
import json
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def extract_text(image_path):
    """
    Načíta obrázok a extrahuje z neho text pomocou pytesseract.
    """
    try:
        image = cv2.imread(image_path)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    except Exception as e:
        print(f"Chyba pri otváraní obrázka: {e}")
        return ""
    text = pytesseract.image_to_string(gray, lang='eng')
    return text

def segment_ui(text):
    """
    Pre demonštračné účely vytvára dummy štruktúru UI,
    ktorá obsahuje global modifiers, vnútorné moduly, LOCK informácie a tagy.
    """
    ui_structure = {
        "globalModifiers": [
            {
                "id": "theme-dark",
                "name": "Dark Mode",
                "style": {"background": "#1e1e1e", "color": "#fff"},
                "modules": [
                    {
                        "id": "player1",
                        "name": "Hazard",
                        "type": "player-link",
                        "layout": {"group": "team", "position": 1},
                        "interactions": {"onClick": "showPlayerDetails('Hazard')"},
                        "tags": ["#TU-funkcia"],
                        "lock": {"level": 1, "reason": "Rozpracovaný návrh", "by": "Visionary"}
                    },
                    {
                        "id": "player2",
                        "name": "Modrić",
                        "type": "player-link",
                        "layout": {"group": "team", "position": 2},
                        "interactions": {"onClick": "showPlayerDetails('Modrić')"},
                        "tags": ["#TU-funkcia"],
                        "lock": {"level": 2, "reason": "Čaká na spätnú väzbu", "by": "Geppetto"}
                    }
                ]
            }
        ]
    }
    return ui_structure

def main():
    image_path = "input_ui.png"  # Uprav cestu k obrázku podľa potreby.
    extracted_text = extract_text(image_path)
    # Pre demonštráciu ignorujeme získaný text a používame dummy segmentáciu.
    ui_structure = segment_ui(extracted_text)
    with open("ui_structure.json", "w", encoding="utf-8") as f:
        json.dump(ui_structure, f, ensure_ascii=False, indent=4)
    print("UI štruktúra bola extrahovaná a uložená do 'ui_structure.json'.")

if __name__ == '__main__':
    main()
