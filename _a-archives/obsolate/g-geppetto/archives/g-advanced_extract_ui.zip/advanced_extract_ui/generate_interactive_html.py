#!/usr/bin/env python3
import json

def generate_html(data):
    html = """<!DOCTYPE html>
<html lang="sk">
<head>
  <meta charset="UTF-8">
  <title>Interaktívny UI MVP</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    /* Základné štýly */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      background: #f4f4f4;
      transition: background 0.5s, color 0.5s;
    }
    h1 {
      text-align: center;
    }
    /* Global modifier bloky – podklad reflektuje zdroj */
    .global {
      margin: 15px 0;
      padding: 15px;
      border: 2px solid #444;
      border-radius: 5px;
    }
    .global h2 {
      margin: 0;
      cursor: pointer;
      user-select: none;
    }
    /* Kontajner pre vnútorné moduly */
    .module-container {
      margin-top: 10px;
      display: block;
    }
    /* Vnútorné moduly – klikateľné prvky */
    .module {
      margin: 8px 0;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 3px;
      background: #fff;
      cursor: pointer;
      transition: background 0.3s, transform 0.3s;
    }
    .module:hover {
      background: #eaeaea;
      transform: scale(1.02);
    }
    /* LOCK informácie a tagy */
    .lock {
      font-size: 0.9rem;
      color: #d0021b;
      margin-top: 5px;
    }
    .tags {
      font-size: 0.8rem;
      color: #555;
      margin-top: 3px;
    }
    /* Detail panel – zobrazí sa pri kliknutí na modul */
    #detailPanel {
      margin-top: 20px;
      padding: 15px;
      border: 2px solid #007acc;
      border-radius: 5px;
      background: #fff;
    }
    #detailPanel h3 {
      margin-top: 0;
    }
  </style>
</head>
<body>
  <h1>Interaktívny UI MVP</h1>
  <div id="uiContainer">
"""
    # Prechádzame všetky global modifiers
    for gm in data.get("globalModifiers", []):
        style = gm.get("style", {})
        bg = style.get("background", "#ffffff")
        color = style.get("color", "#000000")
        html += f"""    <div class="global" id="{gm.get('id')}" style="background:{bg}; color:{color};">
      <h2 onclick="toggleModules('{gm.get('id')}_modules')">{gm.get('name')} &#9660;</h2>
      <div class="module-container" id="{gm.get('id')}_modules">
"""
        # Vnútorné moduly
        for mod in gm.get("modules", []):
            # Pripravíme detailný text pre modul (LOCK, tagy, interakcie)
            details = f"Module: {mod.get('name')}<br>"
            if mod.get("lock"):
                lock = mod.get("lock")
                details += f"LOCK {lock.get('level')}: {lock.get('reason')} (by {lock.get('by')})<br>"
            if mod.get("tags"):
                details += "Tags: " + " ".join(mod.get("tags")) + "<br>"
            if mod.get("interactions", {}).get("onClick"):
                details += f"onClick: {mod.get('interactions').get('onClick')}"
            # Vložíme modul, zabezpečíme, že pri kliknutí sa spustí funkcia showDetails()
            # Pomocou replace upravíme prípadné apostrofy
            safe_name = mod.get('name').replace("'", "\\'")
            safe_details = details.replace("'", "\\'")
            html += f"""        <div class="module" id="{mod.get('id')}" onclick="showDetails('{safe_name}', '{safe_details}')">
          <strong>{mod.get('name')}</strong>
        </div>
"""
        html += "      </div>\n    </div>\n"
    html += """
  </div>
  <div id="detailPanel">
    <h3>Detail modulu</h3>
    <div id="detailContent">Kliknite na modul pre zobrazenie detailov.</div>
  </div>
  <script>
    // Toggle funkcia na zbalenie/rozbalenie vnútorných modulov
    function toggleModules(containerId) {
      var container = document.getElementById(containerId);
      if (container.style.display === "none" || container.style.display === "") {
        container.style.display = "block";
      } else {
        container.style.display = "none";
      }
    }

    // Zobrazenie detailov modulu v detail paneli
    function showDetails(name, details) {
      var detailContent = document.getElementById("detailContent");
      detailContent.innerHTML = "<strong>" + name + "</strong><br>" + details;
    }
  </script>
</body>
</html>
"""
    return html

def main():
    input_filename = "U_structure.json"
    output_filename = "generated_mvp.html"
    try:
        with open(input_filename, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"Chyba pri načítaní súboru {input_filename}: {e}")
        return

    html_content = generate_html(data)
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"HTML MVP súbor bol úspešne vygenerovaný: {output_filename}")
    except Exception as e:
        print(f"Chyba pri zápise do súboru {output_filename}: {e}")

if __name__ == '__main__':
    main()
