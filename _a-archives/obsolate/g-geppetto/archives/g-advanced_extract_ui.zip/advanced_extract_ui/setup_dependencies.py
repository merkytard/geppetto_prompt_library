#!/usr/bin/env python3
import subprocess
import sys
import os

def install_package(package):
    """Inštaluje daný Python balík pomocou pip."""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", package])
        print(f"Balík '{package}' bol úspešne nainštalovaný.")
    except subprocess.CalledProcessError:
        print(f"Chyba pri inštalácii balíka '{package}'.")
        sys.exit(1)

def auto_install_tesseract():
    """
    Pokúsi sa automaticky doinštalovať Tesseract OCR.
    Na Windows použije winget, na Linux apt-get a na macOS Homebrew.
    """
    if sys.platform.startswith("win"):
        # Pre Windows – pokusíme sa použiť winget
        try:
            subprocess.check_call(["winget", "--version"])
            print("Winget bol nájdený. Inštalujem Tesseract OCR cez winget...")
            subprocess.check_call([
                "winget", "install", "--id=UBMannheim.TesseractOCR", 
                "--silent", "--accept-package-agreements", "--accept-source-agreements"
            ])
        except Exception as e:
            print("Winget nie je dostupný alebo inštalácia zlyhala:")
            print(e)
            print("Prosím, nainštalujte Tesseract OCR manuálne z:")
            print("https://github.com/UB-Mannheim/tesseract/wiki")
            sys.exit(1)
    elif sys.platform.startswith("linux"):
        # Pre Linux – použijeme apt-get
        try:
            print("Linux systém zistený. Inštalujem Tesseract OCR cez apt-get...")
            subprocess.check_call(["sudo", "apt-get", "update"])
            subprocess.check_call(["sudo", "apt-get", "install", "-y", "tesseract-ocr"])
        except Exception as e:
            print("Chyba pri inštalácii Tesseract na Linuxe:")
            print(e)
            sys.exit(1)
    elif sys.platform.startswith("darwin"):
        # Pre macOS – použijeme Homebrew
        try:
            subprocess.check_call(["brew", "--version"])
            print("Homebrew bol nájdený. Inštalujem Tesseract OCR cez Homebrew...")
            subprocess.check_call(["brew", "install", "tesseract"])
        except Exception as e:
            print("Chyba pri inštalácii Tesseract na macOS:")
            print(e)
            sys.exit(1)
    else:
        print(f"OS {sys.platform} nie je podporovaný pre automatickú inštaláciu Tesseract.")
        sys.exit(1)

def check_tesseract():
    """
    Skontroluje, či je Tesseract OCR dostupný.
    Najprv skúsi spustiť príkaz 'tesseract --version'. Ak nie je nájdený,
    overí sa bežná Windows cesta.
    """
    tesseract_cmd = "tesseract"
    try:
        result = subprocess.run([tesseract_cmd, "--version"],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True)
        if result.returncode == 0:
            print("Tesseract OCR je dostupný v PATH.")
            return tesseract_cmd
    except Exception:
        pass

    # Overenie predvolenej Windows cesty
    windows_tesseract = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
    if os.path.exists(windows_tesseract):
        print(f"Tesseract OCR bol nájdený na ceste: {windows_tesseract}")
        return windows_tesseract

    return None

def save_tesseract_path(tesseract_path, filename="tesseract_config.txt"):
    """Uloží cestu k Tesseract OCR do konfiguračného súboru."""
    try:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(tesseract_path)
        print(f"Cesta k Tesseract OCR bola uložená do súboru '{filename}'.")
    except Exception as e:
        print(f"Chyba pri ukladaní konfiguračného súboru: {e}")

def main():
    print("=== Inštalácia potrebných Python knižníc ===")
    install_package("opencv-python")
    install_package("pytesseract")
    
    print("\n=== Kontrola inštalácie Tesseract OCR ===")
    tesseract_path = check_tesseract()
    if not tesseract_path:
        print("Tesseract OCR nebol nájdený. Pokúšam sa ho automaticky nainštalovať...")
        auto_install_tesseract()
        tesseract_path = check_tesseract()
        if not tesseract_path:
            print("Inštalácia Tesseract zlyhala. Prosím, nainštalujte ho manuálne.")
            sys.exit(1)
    save_tesseract_path(tesseract_path)

    print("\nNastavenie bolo úspešné. Môžete spustiť váš projekt.")

if __name__ == '__main__':
    main()
