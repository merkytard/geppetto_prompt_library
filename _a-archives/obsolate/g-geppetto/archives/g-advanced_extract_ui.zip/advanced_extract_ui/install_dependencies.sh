#!/bin/bash
# install_dependencies.sh
# Sofistikovaný skript pre automatické dotiahnutie všetkých potrebných knižníc pre Geppetto Tool.
# Inštaluje Tesseract OCR (podľa OS) a Python balíky: opencv-python a pytesseract.

# Nastavenie, aby skript skončil pri chybe.
set -e

# Funkcie pre farebné logovanie
function log_info {
    echo -e "\033[1;32m[INFO]\033[0m $1"
}

function log_error {
    echo -e "\033[1;31m[ERROR]\033[0m $1"
}

# Funkcia na inštaláciu Tesseract OCR na Linuxe
function install_tesseract_linux {
    log_info "Aktualizujem balíčky cez apt-get..."
    sudo apt-get update
    log_info "Inštalujem Tesseract OCR a vývojové knižnice..."
    sudo apt-get install -y tesseract-ocr libtesseract-dev
}

# Funkcia na inštaláciu Tesseract OCR na macOS cez Homebrew
function install_tesseract_mac {
    log_info "Kontrolujem Homebrew..."
    if ! command -v brew &>/dev/null; then
        log_error "Homebrew nie je nainštalovaný. Nainštalujte ho podľa inštrukcií na https://brew.sh/."
        exit 1
    fi
    log_info "Aktualizujem Homebrew..."
    brew update
    log_info "Inštalujem Tesseract OCR cez Homebrew..."
    brew install tesseract
}

# Funkcia na inštaláciu Tesseract OCR na Windows cez winget
function install_tesseract_windows {
    log_info "Kontrolujem winget..."
    if ! command -v winget &>/dev/null; then
        log_error "Winget nie je nainštalovaný. Prosím, nainštalujte ho alebo Tesseract OCR manuálne z: https://github.com/UB-Mannheim/tesseract/wiki"
        exit 1
    fi
    log_info "Inštalujem Tesseract OCR cez winget..."
    winget install --id=UBMannheim.TesseractOCR --silent --accept-package-agreements --accept-source-agreements
}

# Funkcia, ktorá skontroluje, či je Tesseract OCR už nainštalovaný.
function check_tesseract {
    if command -v tesseract &>/dev/null; then
        log_info "Tesseract OCR je už nainštalovaný."
        return 0
    fi

    # Overenie predvolenej Windows cesty
    windows_tesseract="C:\Program Files\Tesseract-OCR\tesseract.exe"
    if [[ -f "$windows_tesseract" ]]; then
        log_info "Tesseract OCR bol nájdený na ceste: $windows_tesseract"
        return 0
    fi

    return 1
}

# Funkcia, ktorá zabezpečí inštaláciu Tesseract OCR podľa OS, ak nie je nainštalovaný.
function install_tesseract {
    if check_tesseract; then
        return 0
    fi

    case "$OSTYPE" in
        linux-gnu*)
            install_tesseract_linux
            ;;
        darwin*)
            install_tesseract_mac
            ;;
        msys*|cygwin*|win32*)
            install_tesseract_windows
            ;;
        *)
            log_error "Nepodporovaný OS: $OSTYPE. Inštalujte Tesseract OCR manuálne."
            exit 1
            ;;
    esac

    # Overenie opäť po inštalácii
    if check_tesseract; then
        log_info "Tesseract OCR bol úspešne nainštalovaný."
    else
        log_error "Inštalácia Tesseract OCR zlyhala. Prosím, nainštalujte ho manuálne."
        exit 1
    fi
}

# Funkcia na inštaláciu Python balíkov pomocou pip.
function install_python_packages {
    if ! command -v pip &>/dev/null; then
        log_error "pip nebol nájdený. Prosím, nainštalujte pip."
        exit 1
    fi

    log_info "Aktualizujem pip..."
    pip install --upgrade pip
    log_info "Inštalujem Python knižnice: opencv-python a pytesseract..."
    pip install opencv-python pytesseract
}

# Hlavný beh skriptu
log_info "Spúšťam inštaláciu závislostí pre Geppetto Tool..."

install_tesseract
install_python_packages

log_info "Všetky závislosti boli úspešne nainštalované."
