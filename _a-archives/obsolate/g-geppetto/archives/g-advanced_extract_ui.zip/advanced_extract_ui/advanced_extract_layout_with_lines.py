#!/usr/bin/env python3
import cv2
import numpy as np
import pytesseract
import json
import sys
from sklearn.cluster import DBSCAN

# Nastav cestu k Tesseract OCR, ak je potrebné (Windows)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def adjust_levels(image):
    """
    Konvertuje obrázok na grayscale a vykoná histogramovú ekvalizáciu,
    čo zlepší kontrast a vyváženie čiernej a bielej.
    """
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    eq = cv2.equalizeHist(gray)
    return eq

def extract_ui_elements(image, orig_image):
    """
    Načíta obrázok, upravený histogramovou ekvalizáciou, a extrahuje UI prvky pomocou OCR.
    Vracia zoznam modulov a zároveň zachováva pôvodný obrázok pre vizualizáciu.
    """
    # Použijeme predspracovanie: GaussianBlur a prahovanie
    blurred = cv2.GaussianBlur(image, (5,5), 0)
    ret, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    modules = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        if w < 50 or h < 20:
            continue
        aspect_ratio = w / h
        if aspect_ratio < 0.2 or aspect_ratio > 15:
            continue

        roi = orig_image[y:y+h, x:x+w]
        text = pytesseract.image_to_string(roi, lang='eng').strip() or "N/A"
        
        module = {
            "id": f"element_{x}_{y}",
            "name": text,
            "layout": {"x": x, "y": y, "width": w, "height": h},
            "interactions": {"onClick": f"openDetail('{text}')"},
            "tags": ["#extracted"],
            "lock": {"level": 1, "reason": "Auto-extracted element", "by": "AdvancedExtractor"}
        }
        modules.append(module)
    return modules

def detect_lines(image):
    """
    Použije Canny edge detection a Hough transformáciu na detekciu priamok.
    Vracia zoznam priamok.
    """
    edges = cv2.Canny(image, 50, 150, apertureSize=3)
    # HoughLinesP pre segmentované priamky
    lines = cv2.HoughLinesP(edges, rho=1, theta=np.pi/180, threshold=100, minLineLength=50, maxLineGap=10)
    return lines

def draw_lines(image, lines):
    """
    Nakreslí detekované priamky na obrázok.
    """
    if lines is not None:
        for line in lines:
            x1,y1,x2,y2 = line[0]
            cv2.line(image, (x1,y1), (x2,y2), (0,255,0), 2)
    return image

def draw_bubble(image, module):
    """
    Vykreslí zaoblený rámček (bublinku) okolo daného modulu a zapíše text.
    Použije jednoduchý prístup: vykreslí obdĺžnik a potom na rohy nakreslí elipsy.
    """
    x = module["layout"]["x"]
    y = module["layout"]["y"]
    w = module["layout"]["width"]
    h = module["layout"]["height"]
    # Parametre zaoblenia
    radius = int(min(w, h) * 0.2)
    # Nakreslí obdĺžnik
    cv2.rectangle(image, (x+radius, y), (x+w-radius, y+h), (255,0,0), 2)
    cv2.rectangle(image, (x, y+radius), (x+w, y+h-radius), (255,0,0), 2)
    # Nakreslí elipsy na rohy
    cv2.ellipse(image, (x+radius, y+radius), (radius, radius), 180, 0, 90, (255,0,0), 2)
    cv2.ellipse(image, (x+w-radius, y+radius), (radius, radius), 270, 0, 90, (255,0,0), 2)
    cv2.ellipse(image, (x+radius, y+h-radius), (radius, radius), 90, 0, 90, (255,0,0), 2)
    cv2.ellipse(image, (x+w-radius, y+h-radius), (radius, radius), 0, 0, 90, (255,0,0), 2)
    # Zobrazíme text (ak je kratší, inak len ukážeme "Text")
    cv2.putText(image, module["name"][:20], (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
    return image

def generate_layout_structure(image_path):
    """
    Vytvorí hierarchickú štruktúru UI s využitím extrahovaných UI prvkov
    a informácií o detekovaných priamkach. Globálny modifier obsahuje
    upravený pozadí extrahovaného obrázka.
    """
    orig_image = cv2.imread(image_path)
    if orig_image is None:
        print(f"Chyba: Obrázok '{image_path}' sa nepodarilo načítať.")
        sys.exit(1)
    
    adjusted = adjust_levels(orig_image)
    modules = extract_ui_elements(adjusted, orig_image)
    lines = detect_lines(adjusted)
    
    # Vypočítame priemernú farbu z pôvodného obrázka pre globálny štýl
    avg_color = cv2.mean(orig_image)[:3]
    avg_color_hex = '#{:02x}{:02x}{:02x}'.format(int(avg_color[2]), int(avg_color[1]), int(avg_color[0]))
    
    # Na vizualizáciu – vytvoríme kópiu, na ktorej nakreslíme detekované čiary a bublinky
    vis_image = orig_image.copy()
    if lines is not None:
        vis_image = draw_lines(vis_image, lines)
    for mod in modules:
        vis_image = draw_bubble(vis_image, mod)
    
    # Uložíme vizualizovaný obrázok
    cv2.imwrite("output_with_layout.png", vis_image)
    
    # Hierarchická štruktúra – tentokrát jednoducho všetky moduly vložíme do jednej sekcie
    layout_structure = {
        "globalModifiers": [
            {
                "id": "extracted-ui",
                "name": f"Extracted UI from {image_path}",
                "style": {"background": avg_color_hex, "color": "#000"},
                "modules": modules,
                "lines": []  # Môžeš sem uložiť detaily o priamkach, ak chceš
            }
        ]
    }
    return layout_structure

def main():
    if len(sys.argv) < 2:
        print("Použitie: python advanced_extract_layout_with_lines.py <input_image>")
        sys.exit(1)
    image_path = sys.argv[1]
    layout_structure = generate_layout_structure(image_path)
    output_filename = "advanced_layout_structure.json"
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            json.dump(layout_structure, f, ensure_ascii=False, indent=4)
        print(f"Hierarchická UI štruktúra bola uložená do súboru '{output_filename}'.")
        print("Výsledný vizualizovaný obrázok bol uložený ako 'output_with_layout.png'.")
    except Exception as e:
        print(f"Chyba pri ukladaní JSON: {e}")

if __name__ == '__main__':
    main()
