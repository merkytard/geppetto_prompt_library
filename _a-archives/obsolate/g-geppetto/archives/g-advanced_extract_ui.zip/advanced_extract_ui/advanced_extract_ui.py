#!/usr/bin/env python3
import cv2
import numpy as np
import pytesseract
import json
import sys

# Nastav cestu k Tesseract OCR (ak je potrebné)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def extract_ui_elements(image_path):
    """
    Načíta obrázok, spracuje ho a extrahuje UI prvky.
    Vracia JSON štruktúru s globálnym modifierom a vnútornými modulmi.
    """
    # Načítanie obrázka
    image = cv2.imread(image_path)
    if image is None:
        print(f"Chyba: Obrázok '{image_path}' sa nepodarilo načítať.")
        sys.exit(1)
    
    # Vypočítame priemernú farbu pre globálny štýl
    avg_color = cv2.mean(image)[:3]
    # Konverzia BGR na hex (OpenCV používa BGR)
    avg_color_hex = '#{:02x}{:02x}{:02x}'.format(int(avg_color[2]), int(avg_color[1]), int(avg_color[0]))
    
    # Predspracovanie: konverzia na grayscale, rozmazanie a prahovanie
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    # Použijeme Otsuov prah
    ret, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    # Nájdeme kontúry – použijeme RETR_EXTERNAL pre vonkajšie kontúry
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    modules = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        # Filtrovanie malých oblastí – prah môžeš doladiť podľa potreby
        if w < 50 or h < 20:
            continue
        
        # Môžeš pridať ďalšie filtre (napr. podľa pomeru strán)
        aspect_ratio = w / h
        if aspect_ratio < 0.2 or aspect_ratio > 15:
            continue

        # Extrakcia oblasti obrázka (ROI) a OCR
        roi = image[y:y+h, x:x+w]
        text = pytesseract.image_to_string(roi, lang='eng')
        text = text.strip() or "N/A"
        
        module = {
            "id": f"element_{x}_{y}",
            "name": text,
            "type": "ui-element",
            "layout": {
                "x": x,
                "y": y,
                "width": w,
                "height": h
            },
            "interactions": {
                "onClick": f"openDetail('{text}')"
            },
            "tags": ["#extracted"],
            "lock": {
                "level": 1,
                "reason": "Auto-extracted element",
                "by": "AdvancedExtractor"
            }
        }
        modules.append(module)
    
    # Vytvoríme globálny modifier, ktorý obsahuje extrahované moduly
    ui_structure = {
        "globalModifiers": [
            {
                "id": "extracted-ui",
                "name": f"Extracted UI from {image_path}",
                "style": {"background": avg_color_hex, "color": "#000"},
                "modules": modules
            }
        ]
    }
    return ui_structure

def main():
    if len(sys.argv) < 2:
        print("Použitie: python advanced_extract_ui.py <input_image>")
        sys.exit(1)
    image_path = sys.argv[1]
    ui_structure = extract_ui_elements(image_path)
    output_filename = "advanced_ui_structure.json"
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            json.dump(ui_structure, f, ensure_ascii=False, indent=4)
        print(f"UI štruktúra bola úspešne uložená do súboru '{output_filename}'.")
    except Exception as e:
        print(f"Chyba pri ukladaní JSON: {e}")

if __name__ == '__main__':
    main()
