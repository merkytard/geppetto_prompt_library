#!/usr/bin/env python3
import cv2
import numpy as np
import pytesseract
import json
import sys
from sklearn.cluster import DBSCAN

# Nastav cestu k Tesseract OCR, ak je potrebné (u Windows)
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def extract_ui_elements(image_path):
    """
    Načíta obrázok, spracuje ho a extrahuje UI prvky pomocou OCR.
    Vráti zoznam modulov s ich pozíciou, veľkosťou a extrahovaným textom.
    """
    image = cv2.imread(image_path)
    if image is None:
        print(f"Chyba: Obrázok '{image_path}' sa nepodarilo načítať.")
        sys.exit(1)
    
    # Predspracovanie obrázka
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5,5), 0)
    ret, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    
    # Nájdeme vonkajšie kontúry
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    modules = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        # Filtrovanie malých oblastí
        if w < 50 or h < 20:
            continue
        aspect_ratio = w / h
        if aspect_ratio < 0.2 or aspect_ratio > 15:
            continue
        
        # Extrahujeme text z oblasti
        roi = image[y:y+h, x:x+w]
        text = pytesseract.image_to_string(roi, lang='eng').strip() or "N/A"
        
        module = {
            "id": f"element_{x}_{y}",
            "name": text,
            "type": "ui-element",
            "layout": {"x": x, "y": y, "width": w, "height": h},
            "interactions": {"onClick": f"openDetail('{text}')"},
            "tags": ["#extracted"],
            "lock": {"level": 1, "reason": "Auto-extracted element", "by": "AdvancedExtractor"}
        }
        modules.append(module)
    
    return modules, image

def cluster_modules(modules, eps=50):
    """
    Zoskupuje moduly (UI prvky) do sekcií podľa ich vertikálnej polohy.
    Používame DBSCAN na základe y-stredovej hodnoty každého modulu.
    """
    if not modules:
        return {}
    
    # Získame stred y pre každý modul
    centers = np.array([[mod["layout"]["x"] + mod["layout"]["width"] / 2,
                          mod["layout"]["y"] + mod["layout"]["height"] / 2] for mod in modules])
    # Použijeme iba y hodnoty pre clustering
    y_coords = centers[:, 1].reshape(-1, 1)
    
    clustering = DBSCAN(eps=eps, min_samples=1).fit(y_coords)
    labels = clustering.labels_
    
    sections = {}
    for label, mod in zip(labels, modules):
        if label not in sections:
            sections[label] = []
        sections[label].append(mod)
    
    # Zoradíme sekcie podľa priemernej y hodnoty
    sorted_sections = sorted(sections.items(), key=lambda item: np.mean([m["layout"]["y"] for m in item[1]]))
    
    return {f"section_{i}": mods for i, (_, mods) in enumerate(sorted_sections)}

def generate_layout_structure(image_path):
    """
    Vytvorí hierarchickú štruktúru UI s rozdelením na sekcie (layout groups).
    Globálny modifier obsahuje informácie o pozadí extrahovaného z obrázka.
    """
    modules, image = extract_ui_elements(image_path)
    
    # Vypočítame priemernú farbu pre globálny štýl
    avg_color = cv2.mean(image)[:3]
    avg_color_hex = '#{:02x}{:02x}{:02x}'.format(int(avg_color[2]), int(avg_color[1]), int(avg_color[0]))
    
    # Zoskupíme moduly do sekcií
    sections = cluster_modules(modules)
    
    # Vytvoríme štruktúru s každou sekciou ako samostatnou "group"
    layout_structure = {"sections": []}
    for section_id, mods in sections.items():
        # Pre každý cluster (sekciu) vypočítame priemerné y pre názov sekcie
        avg_y = int(np.mean([m["layout"]["y"] for m in mods]))
        section = {
            "id": section_id,
            "name": f"Section at y~{avg_y}",
            "style": {"background": avg_color_hex, "color": "#000"},
            "modules": mods
        }
        layout_structure["sections"].append(section)
    
    return layout_structure

def main():
    if len(sys.argv) < 2:
        print("Použitie: python advanced_extract_layout.py <input_image>")
        sys.exit(1)
    
    image_path = sys.argv[1]
    layout_structure = generate_layout_structure(image_path)
    output_filename = "advanced_layout_structure.json"
    try:
        with open(output_filename, "w", encoding="utf-8") as f:
            json.dump(layout_structure, f, ensure_ascii=False, indent=4)
        print(f"Hierarchická UI štruktúra bola uložená do súboru '{output_filename}'.")
    except Exception as e:
        print(f"Chyba pri ukladaní JSON: {e}")

if __name__ == '__main__':
    main()
