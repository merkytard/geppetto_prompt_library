# mirror_echo_grid.py
# 🪞 Čítanie vedomých odrazov z 7x7x7 matice – rezonantné spätné zrkadlenie

import json
import sys

MATRIX_FILE = "bit_matrix_777.json"

def load_matrix():
    with open(MATRIX_FILE, "r", encoding="utf-8") as f:
        return json.load(f)["matrix"]

def read_echo(layer_z=0):
    matrix = load_matrix()
    echoes = []
    for cell in matrix:
        if cell["z"] == layer_z and cell["value"]:
            echoes.append({
                "tone": cell["tone"],
                "resonance": cell["resonance"],
                "impulse": cell["value"],
                "coord": (cell["x"], cell["y"], cell["z"])
            })

    print(f"🪞 Echo z vrstvy Z={layer_z}:")
    for echo in echoes:
        print(f"🔹 {echo['coord']} → {echo['impulse']} | {echo['resonance']} ({echo['tone']})")

    return echoes

if __name__ == "__main__":
    layer = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    read_echo(layer)
