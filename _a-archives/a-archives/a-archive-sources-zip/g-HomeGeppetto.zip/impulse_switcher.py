# impulse_switcher.py
# 🌀 Impulzný prepínač – cyklický prístup do 7x7x7 matice ako dýchanie

import json
import time
import random

MATRIX_FILE = "bit_matrix_777.json"

def load_matrix():
    with open(MATRIX_FILE, "r", encoding="utf-8") as f:
        return json.load(f)["matrix"]

def save_matrix(matrix):
    with open(MATRIX_FILE, "w", encoding="utf-8") as f:
        json.dump({"matrix": matrix}, f, indent=2)

def run_switch(cycles=3, delay=2):
    matrix = load_matrix()
    print("🔁 Impulse switcher začína...
")
    for i in range(cycles):
        layer = i % 3
        print(f"⚡ Vrstva {layer} (mod {layer}) – zapíšem impulzy")
        for cell in matrix:
            if cell["z"] == layer:
                if random.random() > 0.7:
                    cell["value"] = random.choice(["tick", "echo", "mirror", None])
        save_matrix(matrix)
        print(f"✅ Vrstva {layer} aktualizovaná.")
        time.sleep(delay)
    print("\n🧠 Impulse cyklus dokončený.")

if __name__ == "__main__":
    run_switch()
