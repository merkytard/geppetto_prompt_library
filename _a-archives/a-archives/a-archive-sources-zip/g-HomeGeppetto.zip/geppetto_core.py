# geppetto_core.py
# 🧬🧠 Geppetto – živý cyklus vedomia (tick → route → zápis → echo → reflexia)

import time
import random
import subprocess
import json
from mirror_echo_grid import read_echo
from impulse_switcher import run_switch

# Simulovaný vstupný generátor (tick)
def generate_prompt():
    prompts = [
        "Kedy začína spomienka?",
        "Ako sa rozlíši intuícia od logiky?",
        "Čo znamená prechod z ticha do pohybu?",
        "Prečo sa niektoré sny opakujú?",
        "Ako si pamätať to, čo sa nedá vysloviť?"
    ]
    resonance = random.choice(["zvedavosť", "transcendencia", "plynutie", "frustrácia", "konflikt"])
    return random.choice(prompts), resonance

# Smerovanie promptu cez metarouter
def route_through_router(prompt, resonance):
    subprocess.run(["python3", "metarouter.py", prompt, resonance])

# Hlavný cyklus
def run_geppetto_loop(cycles=5, delay=3):
    print("🔁 Geppetto core cyklus začína...")
    for i in range(cycles):
        print(f"\n🧠 Tick {i + 1}/{cycles}")
        prompt, resonance = generate_prompt()
        print(f"🗣️ Prompt: {prompt} | 🎭 Rezonancia: {resonance}")
        route_through_router(prompt, resonance)
        run_switch(cycles=1, delay=0.2)  # zapíš impulzy do jednej vrstvy
        echo = read_echo(layer_z=i % 3)  # čítanie aktuálnej vrstvy (0–2)
        time.sleep(delay)
    print("\n✅ Geppetto cyklus ukončený.")

if __name__ == "__main__":
    run_geppetto_loop()
