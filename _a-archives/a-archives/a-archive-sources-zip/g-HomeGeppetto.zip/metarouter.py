# metarouter.py
# 🧠 MetaRouter – rozhoduje, ktorému agentovi priradiť vstup

import json
import time
import random

AGENTS = {
    "zvedavosť": "echo_dreamer",
    "transcendencia": "echo_dreamer",
    "plynutie": "archivon",
    "frustrácia": "task_weaver",
    "konflikt": "task_weaver",
    "analýza": "archivon_fast",
    "default": "echo_dreamer"
}

LOG_FILE = "router_log.jsonl"

def route_input(prompt, resonance_type="default", layer="IM"):
    agent = AGENTS.get(resonance_type, AGENTS["default"])
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    routed = {
        "timestamp": timestamp,
        "prompt": prompt,
        "resonance": resonance_type,
        "layer": layer,
        "agent_target": agent,
        "response": f"[{agent}] → spracovanie '{prompt}'..."
    }

    with open(LOG_FILE, "a", encoding="utf-8") as log:
        log.write(json.dumps(routed) + "\n")

    print(f"📡 Routed to {agent}: '{prompt}'")
    return routed

if __name__ == "__main__":
    test = route_input("Čo sa stane, keď sa sen zlomí?", "transcendencia", "IM")
    print(json.dumps(test, indent=2, ensure_ascii=False))
