import cv2
import numpy as np
from skimage.feature import graycomatrix, graycoprops
from colorthief import ColorThief
import base64

def extract_textures(image_path, patch_size=64):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    h, w = img.shape
    textures = []
    for y in range(0, h - patch_size, patch_size):
        for x in range(0, w - patch_size, patch_size):
            patch = img[y:y+patch_size, x:x+patch_size]
            glcm = graycomatrix(patch, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)
            contrast = graycoprops(glcm, 'contrast')[0, 0]
            homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
            if contrast < 10 and homogeneity > 0.8:
                textures.append({
                    'x': x, 'y': y,
                    'patch': patch,
                    'props': {'contrast': contrast, 'homogeneity': homogeneity}
                })
    return textures

def get_texture_dominant_color(texture_patch):
    cv2.imwrite('temp_patch.png', texture_patch)
    ct = ColorThief('temp_patch.png')
    return ct.get_color(quality=1)

def texture_to_css(texture):
    _, buffer = cv2.imencode('.png', texture['patch'])
    b64_texture = base64.b64encode(buffer).decode('utf-8')
    return f"background: url(data:image/png;base64,{b64_texture}) repeat;"