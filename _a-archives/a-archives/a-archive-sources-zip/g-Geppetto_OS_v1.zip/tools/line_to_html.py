import cv2
import numpy as np
import torch
import os
import requests
from PIL import Image
from segment_anything import sam_model_registry, SamPredictor
from hawpy import HAWP
from colorthief import ColorThief

class CompleteLineProcessor:
    def __init__(self, device="cuda" if torch.cuda.is_available() else "cpu"):
        self.device = device
        self._download_models()
        self.sam = self._init_sam()
        self.hawp = HAWP(pretrained=True).to(self.device).eval()

    def _download_models(self):
        models = {
            "sam_vit_h_4b8939.pth": "https://dl.fbaipublicfiles.com/segment_anything/sam_vit_h_4b8939.pth",
            "hawp_weights.pth": "https://github.com/cherubicXN/hawp/releases/download/v1.0.0/hawp_512.pth"
        }
        os.makedirs("models", exist_ok=True)
        for name, url in models.items():
            path = f"models/{name}"
            if not os.path.exists(path):
                r = requests.get(url, stream=True)
                with open(path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

    def _init_sam(self):
        sam_checkpoint = "models/sam_vit_h_4b8939.pth"
        model_type = "vit_h"
        sam = sam_model_registry[model_type](checkpoint=sam_checkpoint).to(self.device)
        return SamPredictor(sam)

    def _remove_text(self, image):
        self.sam.set_image(image)
        masks, _, _ = self.sam.predict("text, words, letters, numbers")
        if masks.shape[0] == 0:
            return image
        mask = masks[0].astype(np.uint8)
        return cv2.inpaint(image, mask, 3, cv2.INPAINT_TELEA)

    def _detect_lines(self, image):
        img_tensor = torch.from_numpy(image).permute(2,0,1).unsqueeze(0).float() / 255.0
        with torch.no_grad():
            outputs = self.hawp(img_tensor.to(self.device))
        return outputs['lines'][0].cpu().numpy()

    def _merge_lines(self, lines, angle_thresh=5, dist_thresh=20):
        merged = []
        for line in lines:
            x1, y1, x2, y2 = line[:4]
            angle = np.degrees(np.arctan2(y2-y1, x2-x1))
            matched = False
            for m in merged:
                ma = np.degrees(np.arctan2(m[3]-m[1], m[2]-m[0]))
                if abs(angle - ma) < angle_thresh:
                    dist = np.linalg.norm(np.array([x1,y1]) - np.array([m[0],m[1]]))
                    if dist < dist_thresh:
                        merged.remove(m)
                        new_line = [min(x1,m[0]), min(y1,m[1]), max(x2,m[2]), max(y2,m[3])]
                        merged.append(new_line)
                        matched = True
                        break
            if not matched:
                merged.append([x1,y1,x2,y2])
        return np.array(merged)

    def _get_dominant_color(self, image_path):
        ct = ColorThief(image_path)
        return ct.get_color(quality=1)

    def process_image(self, image_path):
        image = cv2.cvtColor(cv2.imread(image_path), cv2.COLOR_BGR2RGB)
        cleaned = self._remove_text(image)
        lines = self._detect_lines(cleaned)
        merged_lines = self._merge_lines(lines)
        bg_color = self._get_dominant_color(image_path)
        html = ['<!DOCTYPE html><html><head><style>']
        html.append(f'.container {{ background: rgb{bg_color}; position: relative; }}')
        html.append('.line { position: absolute; border: 2px solid black; }')
        html.append('</style></head><body><div class="container">')
        for line in merged_lines:
            x1, y1, x2, y2 = line.astype(int)
            if abs(x1 - x2) > abs(y1 - y2):
                html.append(f'<hr style="position: absolute; top: {y1}px; left: {x1}px; width: {x2-x1}px">')
            else:
                html.append(f'<div class="line" style="left: {x1}px; top: {y1}px; height: {y2-y1}px"></div>')
        html.append('</div></body></html>')
        return '\n'.join(html)